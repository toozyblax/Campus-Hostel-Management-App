from flask import Blueprint, render_template, redirect, url_for
from flask_login import current_user

views = Blueprint('views', __name__)

def get_user_dashboard_url(role):
    if role == 'Owner':
        return url_for('owner.dashboard')
    elif role == 'Warden':
        return url_for('warden.dashboard')
    elif role == 'Subwarden':
        return url_for('subwarden.dashboard')
    elif role == 'Admin':
        return url_for('admin.dashboard')
    return url_for('views.home')


@views.route('/')
@views.route('/home')
def home():
    if current_user.is_authenticated:
        return redirect(get_user_dashboard_url(current_user.role))
    return render_template("home.html", user=current_user)