from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager
from flask_migrate import Migrate
from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
from sqlalchemy import text

db = SQLAlchemy()

def create_app():
    app = Flask(__name__)
    
    login_manager = LoginManager()
    DB_NAME = "database.db"
    app.config['SECRET_KEY'] = 'password2024' 
    # Database configuration
    app.config['SQLALCHEMY_BINDS'] = {
        'users': f'sqlite:///{DB_NAME}',
    }
    app.config['SQLALCHEMY_DATABASE_URI'] = f'sqlite:///{DB_NAME}'
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
    db.init_app(app)
    migrate=Migrate(app, db)
    
    from .views import views
    from .auth import auth
    from .models import User

    from .owner import owner  
    from .warden import warden
    from .sub_warden import sub_warden
    from .admin import admin
    
    app.register_blueprint(views, url_prefix='/')
    app.register_blueprint(auth, url_prefix='/')
    app.register_blueprint(owner, url_prefix='/owner')
    app.register_blueprint(warden, url_prefix='/warden')
    app.register_blueprint(sub_warden, url_prefix='/sub-warden')
    app.register_blueprint(admin, url_prefix='/admin')


    login_manager.login_view = 'auth.login'
    login_manager.init_app(app)

    @login_manager.user_loader
    def load_user(user_id):
        return User.query.get(int(user_id))

    # 5. Create database tables
    with app.app_context():
        db.create_all()
    return app

def rename_columns_with_sql():
    """
    Executes raw SQL ALTER TABLE commands to rename the necessary columns.
    """
    app = create_app()
    with app.app_context():
        try:
            # 1. Rename column in the Faculty table: 'code' to 'faculty_code'
            db.session.execute(text("ALTER TABLE faculty RENAME COLUMN code TO faculty_code;"))
            
            # 2. Rename column in the Student table: 'program_code' to 'faculty_code'
            #    (SQLite uses 'program_code' if the old Python model used snake_case for the column name)
            db.session.execute(text("ALTER TABLE student RENAME COLUMN program_code TO faculty_code;"))

            db.session.commit()
            print("✅ Database columns renamed successfully: 'code' -> 'faculty_code' (Faculty) and 'program_code' -> 'faculty_code' (Student).")
            
        except Exception as e:
            db.session.rollback()
            print(f"❌ ERROR renaming columns: {e}")
            print("NOTE: If you are using SQLite, the RENAME COLUMN syntax is often restrictive. If this fails, you MUST use Alembic or a series of CREATE/COPY/DROP commands.")