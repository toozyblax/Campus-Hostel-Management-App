from flask import Blueprint, render_template

warden = Blueprint('warden', __name__)

@warden.route('/dashboard')
def dashboard():
    return render_template('Warden/warden_dashboard.html')

@warden.route('/room-condition-form')
def room_condition_form():
    return render_template('Warden/room_condition_form.html')

@warden.route('/student-checkin')
def student_checkin():
    return render_template('Warden/student_checkin.html')

@warden.route('/student-checkout')
def student_checkout():
    return render_template('Warden/student_checkout.html')
