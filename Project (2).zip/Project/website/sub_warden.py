from flask import Blueprint, render_template

sub_warden = Blueprint('sub-warden', __name__)

@sub_warden.route('/dashboard')
def dashboard():
    return render_template('Subwarden/sub_warden_dashboard.html')

@sub_warden.route('/hostel-reports')
def hostel_reports():
    return render_template('Subwarden/hostel_report_form.html')

@sub_warden.route('/view-reports')
def view_reports():
    return render_template('Subwarden/view_my_reports.html')