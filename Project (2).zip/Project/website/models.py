from . import db
from flask_login import UserMixin

class User(db.Model, UserMixin):
    id = db.Column(db.Integer, primary_key=True)
    first_name = db.Column(db.String(150), nullable=False)
    last_name = db.Column(db.String(150), nullable=False)
    username = db.Column(db.String(150), unique=True, nullable=False)
    email = db.Column(db.String(150), unique=True, nullable=True)
    password = db.Column(db.String(150), nullable=False)
    role = db.Column(db.String(50), nullable=False)

    def __repr__(self):
        return f'<User {self.username} | Role: {self.role}>'
    
class Student(db.Model):
    __tablename__ = 'student'

    reg_no = db.Column(db.String(20), primary_key=True)
    first_name = db.Column(db.String(100), nullable=False)
    last_name = db.Column(db.String(100), nullable=False)
    gender = db.Column(db.String(10))

    # Relationship: Many students belong to one faculty
    faculty_code = db.Column(db.String(10), db.ForeignKey('faculty.faculty_code'), nullable=False)

    # Relationship: One-to-One with Resident (A student is either a resident or not)
    residence_history = db.relationship('Resident', backref='student', uselist=False, lazy=True)

    def __repr__(self):
        return f"Student('{self.reg_no}', '{self.first_name} {self.last_name}')"

class Faculty(db.Model):
    """Stores academic faculties for students."""
    __tablename__ = 'faculty'

    faculty_code = db.Column(db.String(10), primary_key=True)
    name = db.Column(db.String(150), unique=True, nullable=False)

    students = db.relationship('Student', backref='faculty', lazy=True)

class Hostel(db.Model):
    __tablename__ = 'hostel'

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), unique=True, nullable=False)
    gender_type = db.Column(db.String(10), nullable=False, default='Co-ed')
    is_active = db.Column(db.Boolean, default=True)

    
    rooms = db.relationship('Room', backref='hostel', lazy=True)
    conditions = db.relationship('HostelCondition', backref='hostel', lazy=True)
    
    def __repr__(self):
        return f"Hostel('{self.name}', Active: {self.is_active})"

class Room(db.Model):
    """Stores details for individual rooms."""
    __tablename__ = 'room'

    id = db.Column(db.Integer, primary_key=True)
    hostel_id = db.Column(db.Integer, db.ForeignKey('hostel.id'), nullable=False)
    room_number = db.Column(db.String(10), nullable=False) # e.g., '101A', 'G05'
    max_residents = db.Column(db.Integer, nullable=False)
    is_active_for_booking = db.Column(db.Boolean, default=True)



    __table_args__ = (db.UniqueConstraint('hostel_id', 'room_number', name='_hostel_room_uc'),)

    residents = db.relationship('Resident', backref='room', lazy=True)
    condition = db.relationship('RoomCondition', backref='room', uselist=False, lazy=True)

    @property
    def is_full(self):
        return len(self.residents) >= self.max_residents

    @property
    def is_available(self):
        return self.is_active_for_booking and not self.is_full

class RoomCondition(db.Model):
    __tablename__ = 'room_condition'

    id = db.Column(db.Integer, primary_key=True)
    
    # Foreign Key to Room
    room_id = db.Column(db.Integer, db.ForeignKey('room.id'), nullable=False)
    
    # Warden's signature date
    report_date = db.Column(db.DateTime, default=db.func.now())

    # Condition fields (using Boolean for simple status checks, or String for notes)
    sockets = db.Column(db.String(50), default='Good')
    wardrobes = db.Column(db.String(50), default='Good')
    cupboards = db.Column(db.String(50), default='Good')
    chairs = db.Column(db.String(50), default='Good')
    beds = db.Column(db.String(50), default='Good')
    matraces = db.Column(db.String(50), default='Good')
    light = db.Column(db.String(50), default='Good')
    curtains = db.Column(db.String(50), default='Good')
    
    # Relationship: One-to-One with Resident (The specific checkin this report belongs to)
    resident_checkin = db.relationship('Resident', backref='checkin_condition', uselist=False, lazy=True)

class Resident(db.Model):
    """Records a student's check-in/residency status."""
    __tablename__ = 'resident'

    id = db.Column(db.Integer, primary_key=True)
    
    student_reg_no = db.Column(db.String(20), db.ForeignKey('student.reg_no'), nullable=False) 
    room_id = db.Column(db.Integer, db.ForeignKey('room.id'), nullable=False)
    check_in_date = db.Column(db.DateTime, nullable=False, default=db.func.now())
    check_out_date = db.Column(db.DateTime, nullable=True)
    checkin_condition_id = db.Column(db.Integer, db.ForeignKey('room_condition.id'), unique=True, nullable=True)

class HostelCondition(db.Model):
    __tablename__ = 'hostel_condition'

    id = db.Column(db.Integer, primary_key=True)
    
    # Foreign Key to Hostel
    hostel_id = db.Column(db.Integer, db.ForeignKey('hostel.id'), nullable=False)
    
    condition_description = db.Column(db.Text, nullable=False)
    reported_by_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    reported_date = db.Column(db.DateTime, default=db.func.now())
    
    # Status
    is_attended = db.Column(db.Boolean, default=False)
    attended_date = db.Column(db.DateTime, nullable=True)

    reporter = db.relationship('User', backref='hostel_reports', lazy=True)