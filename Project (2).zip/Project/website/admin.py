from flask import Blueprint, render_template, request, flash, redirect, url_for
from werkzeug.security import generate_password_hash, check_password_hash
from flask_login import login_user, login_required, logout_user, current_user
from .models import Student, Resident, Room
from . import db
from sqlalchemy.orm import joinedload

admin = Blueprint('admin', __name__)

@admin.route('/add_student', methods=['POST'])
def add_student():
    if current_user.role != 'Admin':
        flash('Access denied. Access available for admin.', category='error')
        return redirect(url_for('views.home'))
    if request.method == 'POST':
        student_id = request.form.get('reg_no').upper().strip()
        first_name = request.form.get('first_name').upper().strip()
        last_name = request.form.get('last_name').upper().strip()
        gender = request.form.get('gender').upper().strip()
        faculty_code = request.form.get('faculty_code').upper().strip()

        student_exists = Student.query.filter_by(reg_no=student_id).first()
        if student_exists:
            flash('Student with this ID already exists.', category='error')
            return redirect(url_for('admin.manage_students'))
        reg_no = "R253920Q"
        
        if not all([student_id, first_name, last_name, gender, faculty_code]):
            flash('All fields are required.', category='error')
            return redirect(url_for('admin.manage_students'))
        
        reg_prefix = reg_no[0]
        if student_id[0].upper() != reg_prefix.upper() and len(student_id) != 8:
            flash(f'Student ID must start with "{reg_prefix}" and be 8 characters long.', category='error')
            return redirect(url_for('admin.manage_students'))

        new_student = Student(reg_no=student_id, first_name=first_name, last_name=last_name, gender=gender,
                               faculty_code=faculty_code)
        try:
            db.session.add(new_student)
            db.session.commit()
            flash(f'Student {first_name} {last_name} added successfully!', category='success')
        except Exception as e:
            db.session.rollback()
            flash(f'Error adding student: {e}', category='error')
        return redirect(url_for('admin.manage_students'))
    return render_template('Admin/add_student.html')

@admin.route('/manage_students', methods=['POST', 'GET'])
def manage_students():
    if current_user.role != 'Admin':
        flash('Access denied. Access available for admin.', category='error')
        return redirect(url_for('views.home'))
    students = Student.query.all()
    return render_template('Admin/manage_students.html', students=students)

@admin.route('/manage_users', methods=['GET'])
def manage_users():
    return render_template('Admin/manage_users.html')

@admin.route('/delete_student', methods=['POST'])
def delete_student():
    if current_user.role != 'Admin':
        flash('Access denied. Access available for admin.', category='error')
        return redirect(url_for('views.home'))

    reg_no_to_delete = request.form.get('student_reg_no')
    if not reg_no_to_delete:
        flash('No student ID provided for deletion.', category='error')
        return redirect(url_for('admin.manage_students'))

    student = Student.query.filter_by(reg_no=reg_no_to_delete).first()

    if not student:
        flash(f'Student with ID {reg_no_to_delete} not found.', category='error')
        return redirect(url_for('admin.manage_students'))

    try:
        # 3. Handle Referential Integrity (Resident Records)
        
        # Find all current and past residency records for this student
        resident_records = Resident.query.filter_by(student_reg_no=reg_no_to_delete).all()
        
        if resident_records:
            # Delete all related Resident records FIRST
            for record in resident_records:
                db.session.delete(record)
            
            flash(f"Deleted {len(resident_records)} associated residency records.", category='warning')

        # 4. Delete the Student Record
        db.session.delete(student)
        db.session.commit()

        flash(f'Student {student.first_name} {student.last_name} ({reg_no_to_delete}) deleted successfully.', category='success')
        
    except Exception as e:
        db.session.rollback()
        flash(f'An error occurred during deletion: {e}', category='error')
        
    return redirect(url_for('admin.manage_students'))

@admin.route('/dashboard', methods=['POST', 'GET'])
def dashboard():
    return render_template('Admin/dashboard.html')