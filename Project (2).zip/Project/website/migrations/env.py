# C:\Users\Chandler\Desktop\Project\website\migrations\env.py

import os
import sys
from os.path import abspath, dirname

# --- FINAL PATH FIX ---
# Calculate the path to the 'website' directory itself (up one level)
WEBSITE_DIR = dirname(abspath(__file__)) 
# Append the parent directory of 'website' (C:\Users\Chandler\Desktop\Project) to the path
sys.path.insert(0, os.path.realpath(os.path.join(os.path.dirname(__file__), '..', '..')))
# --- END PATH FIX ---


import logging
from logging.config import fileConfig

from flask import current_app
from alembic import context

# Now that the parent directory is on the path, this import should succeed
# if you have website/__init__.py
from website import db, create_app # Assuming create_app is defined in __init__.py

# Note: Removed redundant 'from logging.config import fileConfig' import

# this is the Alembic Config object
config = context.config

# Interpret the config file for Python logging.
fileConfig(config.config_file_name)
logger = logging.getLogger('alembic.env')

# --- Start of the standard setup functions ---

def get_engine():
    # This function relies on current_app being set up, which happens in run_migrations()
    try:
        # this works with Flask-SQLAlchemy<3 and Alchemical
        return current_app.extensions['migrate'].db.get_engine()
    except (TypeError, AttributeError):
        # this works with Flask-SQLAlchemy>=3
        return current_app.extensions['migrate'].db.engine

def get_engine_url():
    try:
        return get_engine().url.render_as_string(hide_password=False).replace(
            '%', '%%')
    except AttributeError:
        return str(get_engine().url).replace('%', '%%')

target_metadata = db.Model.metadata
# Note: Removed the automatic config.set_main_option('sqlalchemy.url', get_engine_url())
# This is handled by Flask-Migrate later, but leaving it commented out is fine.
# config.set_main_option('sqlalchemy.url', get_engine_url()) 
# target_db = current_app.extensions['migrate'].db # This will be set inside run_migrations_online

def get_metadata():
    # Ensure this uses the correct variable name if you need to use target_db
    # For a simple app, using db.Model.metadata (defined above) is sufficient.
    return db.Model.metadata


def run_migrations_offline():
    """Run migrations in 'offline' mode."""
    url = config.get_main_option("sqlalchemy.url")
    context.configure(
        url=url, target_metadata=get_metadata(), literal_binds=True
    )

    with context.begin_transaction():
        context.run_migrations()


def run_migrations_online():
    """Run migrations in 'online' mode."""
    # Ensure current_app.extensions['migrate'] is accessible
    target_db = current_app.extensions['migrate'].db 
    
    def process_revision_directives(context, revision, directives):
        if getattr(config.cmd_opts, 'autogenerate', False):
            script = directives[0]
            if script.upgrade_ops.is_empty():
                directives[:] = []
                logger.info('No changes in schema detected.')

    conf_args = current_app.extensions['migrate'].configure_args
    if conf_args.get("process_revision_directives") is None:
        conf_args["process_revision_directives"] = process_revision_directives

    connectable = get_engine()

    with connectable.connect() as connection:
        context.configure(
            connection=connection,
            target_metadata=target_db.metadata, # Use target_db metadata here
            **conf_args
        )

        with context.begin_transaction():
            context.run_migrations()

# --- START: Execution Context Fix ---
# THIS IS WHERE WE MANUALLY LOAD THE FLASK APP AND PUSH CONTEXT

def run_migrations_with_context():
    # 1. Load your Flask app
    app = create_app()

    # 2. Run migrations within the application context
    with app.app_context():
        if context.is_offline_mode():
            run_migrations_offline()
        else:
            run_migrations_online()

run_migrations_with_context()
# --- END: Execution Context Fix ---