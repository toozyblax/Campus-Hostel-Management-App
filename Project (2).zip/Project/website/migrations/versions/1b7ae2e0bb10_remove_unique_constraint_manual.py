"""remove_unique_constraint_manual

Revision ID: 1b7ae2e0bb10
Revises: 
Create Date: 2025-10-05 17:43:45.781835

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '1b7ae2e0bb10'
down_revision = None
branch_labels = None
depends_on = None


def upgrade():
    op.rename_table('resident', '_resident_old')

    # 2. Create the new table without the UNIQUE constraint on student_reg_no
    op.create_table('resident',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('student_reg_no', sa.String(20), sa.ForeignKey('student.reg_no'), nullable=False), # UNIQUE constraint is now missing
        sa.Column('room_id', sa.Integer(), sa.ForeignKey('room.id'), nullable=False),
        sa.Column('check_in_date', sa.DateTime(), nullable=False),
        sa.Column('check_out_date', sa.DateTime(), nullable=True),
        sa.Column('checkin_condition_id', sa.Integer(), sa.ForeignKey('room_condition.id'), unique=True, nullable=True),
        sa.PrimaryKeyConstraint('id')
    )
    
    # 3. Copy data from the old table to the new table
    op.execute(
        """
        INSERT INTO resident (id, student_reg_no, room_id, check_in_date, check_out_date, checkin_condition_id) 
        SELECT id, student_reg_no, room_id, check_in_date, check_out_date, checkin_condition_id 
        FROM _resident_old
        """
    )
    
    # 4. Drop the old table
    op.drop_table('_resident_old')

def downgrade():
    op.rename_table('resident', '_resident_old')
    
    # 2. Create the original table with the UNIQUE constraint on student_reg_no
    op.create_table('resident',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('student_reg_no', sa.String(20), sa.ForeignKey('student.reg_no'), unique=True, nullable=False), # UNIQUE constraint IS back
        sa.Column('room_id', sa.Integer(), sa.ForeignKey('room.id'), nullable=False),
        sa.Column('check_in_date', sa.DateTime(), nullable=False),
        sa.Column('check_out_date', sa.DateTime(), nullable=True),
        sa.Column('checkin_condition_id', sa.Integer(), sa.ForeignKey('room_condition.id'), unique=True, nullable=True),
        sa.PrimaryKeyConstraint('id')
    )
    
    # 3. Copy data back (Note: This will fail if your data now violates the UNIQUE constraint!)
    op.execute(
        """
        INSERT INTO resident (id, student_reg_no, room_id, check_in_date, check_out_date, checkin_condition_id) 
        SELECT id, student_reg_no, room_id, check_in_date, check_out_date, checkin_condition_id 
        FROM _resident_old
        """
    )
    
    # 4. Drop the old table
    op.drop_table('_resident_old')
