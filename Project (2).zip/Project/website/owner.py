from flask import Blueprint, render_template, request, flash, redirect, url_for
from sqlalchemy.orm import joinedload
from flask_login import login_required, current_user
from . import db
from .models import Hostel, Room, Student, Resident
from sqlalchemy import func

owner = Blueprint('owner', __name__)

@owner.route('/dashboard')
def dashboard():
    return render_template('Owner/owner_dashboard.html')

@owner.route('/managehostels', methods=['GET', 'POST'])
def manage_hostels():

    if current_user.role != 'Owner':
        flash('Access denied. Access available for owner.', category='error')
        return redirect(url_for('views.home'))
    
    all_hostels = Hostel.query.all()
    hostel_name = request.form.get('hostel_name')
    gender_type = request.form.get('gender_type')

    # 2. Check if the request is a POST (Form Submission)
    if request.method == 'POST':
        hostel_name = request.form.get('hostel_name')
        gender_type = request.form.get('gender_type')
        
        # 3. Input Validation
        if not hostel_name or not gender_type:
            flash('Hostel name and gender type are required.', category='error')
            return redirect(url_for('owner.manage_hostels'))
            
        # 4. Existence Verification and DB Logic (Your original logic)
        existing_hostel = Hostel.query.filter_by(name=hostel_name.upper().strip()).first()
        if existing_hostel:
            flash(f'Hostel name "{hostel_name}" already exists. Please choose a different name.', category='error')
            return redirect(url_for('owner.manage_hostels'))
            
        try:
            new_hostel = Hostel(
                name=hostel_name.upper().strip(), # Trim/uppercase applied here
                gender_type=gender_type,
                is_active=True
            )
            db.session.add(new_hostel)
            db.session.commit()
            flash(f'Hostel "{hostel_name.strip()}" ({gender_type}) successfully added.', category='success')
        except Exception as e:
            db.session.rollback()
            flash(f'An unexpected error occurred: {e}', category='error')
        else:
            return redirect(url_for('owner.manage_hostels'))
    return render_template('Owner/manage_hostels.html', hostels=all_hostels)

from flask import Blueprint, request, redirect, url_for, flash


@owner.route('/toggle-hostel-status', methods=['POST'])

#CHANGE HOSTEL STATUS
def toggle_hostel_status():
    if current_user.role != 'Owner':
        flash('Access denied. Only Owners can manage hostel status.', category='error')
        return redirect(url_for('views.home'))
    
    hostel_id = request.form.get('hostel_id')

    if not hostel_id:
        flash('Invalid request: Hostel ID is missing.', category='error')
        return redirect(url_for('owner.manage_hostels'))

    hostel = db.session.get(Hostel, int(hostel_id))

    if not hostel:
        flash(f'Error: Hostel with ID {hostel_id} not found.', category='error')
        return redirect(url_for('owner.manage_hostels'))

    try:
        current_state = hostel.is_active
        hostel.is_active = not current_state
        
        db.session.commit()

        new_status = "Active" if hostel.is_active else "Inactive"
        flash(f'Hostel "{hostel.name}" status successfully changed to {new_status}.', category='success')
    
    except Exception as e:
        # Rollback in case of any database error
        db.session.rollback()
        flash(f'An unexpected error occurred while updating status: {e}', category='error')

    # 6. Redirect back to the management page
    return redirect(url_for('owner.manage_hostels'))

#DELETE HOSTEL
@owner.route('/delete-hostel', methods=['POST'])
def delete_hostel():
    if current_user.role != 'Owner':
        flash('Access denied. Only Owners can delete hostels.', category='error')
        return redirect(url_for('views.home'))


    hostel_id = request.form.get('hostel_id')

    if not hostel_id:
        flash('Invalid request: Hostel ID is missing.', category='error')
        return redirect(url_for('owner.manage_hostels'))

    # 3. Fetch the Hostel
    try:
        # Fetch the hostel record
        hostel = db.session.get(Hostel, int(hostel_id))
        
        if not hostel:
            flash(f'Error: Hostel with ID {hostel_id} not found.', category='error')
            return redirect(url_for('owner.manage_hostels'))

        hostel_name = hostel.name # Store name before deletion for flash message
        db.session.delete(hostel)
        db.session.commit()

        flash(f'Hostel "{hostel_name}" and all associated data successfully deleted.', category='success')
    
    except Exception as e:
        # Rollback in case of any database error (e.g., foreign key constraints)
        db.session.rollback()
        flash(f'An unexpected error occurred while deleting the hostel: {e}', category='error')

    # 5. Redirect back to the management page
    return redirect(url_for('owner.manage_hostels'))


#MANAGE ROOMS PAGE
@owner.route('/managerooms', methods=['GET'])
def manage_rooms():
    if current_user.role != 'Owner':
        flash('Access denied.', category='error')
        return redirect(url_for('views.home'))
        
    all_hostels = Hostel.query.all()
    all_rooms_with_hostel = (
        db.session.query(Room)
        .options(joinedload(Room.hostel))
        .all()
    )

    return render_template(
        'Owner/manage_rooms.html', 
        hostels=all_hostels, rooms=all_rooms_with_hostel,
        user=current_user
    )

#CHANGE ROOM STATUS
@owner.route('/toggle-room-status', methods=['POST'])
def toggle_room_status():
    if current_user.role != 'Owner':
        flash('Access denied. Only Owners can manage room status.', category='error')
        return redirect(url_for('views.home'))
    
    room_id = request.form.get('room_id')

    if not room_id:
        flash('Invalid request: Room ID is missing.', category='error')
        return redirect(url_for('owner.manage_rooms'))

    room = db.session.get(Room, int(room_id))

    if not room:
        flash(f'Error: Room with ID {room_id} not found.', category='error')
        return redirect(url_for('owner.manage_rooms'))

    try:
        current_state = room.is_active_for_booking
        room.is_active_for_booking = not current_state

        db.session.commit()

        new_status = "Active" if room.is_active_for_booking else "Inactive"
        flash(f'Room "{room.room_number}" status successfully changed to {new_status}.', category='success')
    
    except Exception as e:
        db.session.rollback()
        flash(f'An unexpected error occurred while updating status: {e}', category='error')

    return redirect(url_for('owner.manage_rooms'))

#ADD ROOM
@owner.route('/add-room', methods=['POST'])
@login_required
def add_room():
    hostel_id = request.form.get('hostel_id')
    room_number = request.form.get('room_number').upper().strip()
    maximum_occupancy = request.form.get('maximum_occupancy')

    hostel_exists = db.session.get(Hostel, int(hostel_id))
    room_exists = Room.query.filter(
        Room.room_number == room_number,
        Room.hostel_id == hostel_id
    ).first() 


    if not all([hostel_id, room_number, maximum_occupancy]) or not hostel_exists:
        flash('All fields are required and the selected hostel should exist.', category='error')
        return redirect(url_for('owner.manage_rooms'))
    
    if room_exists:
        flash("Room already exists", category='error')
        return redirect(url_for('owner.manage_rooms'))

    new_room = Room(
    hostel_id=hostel_id,
    room_number=room_number,
    max_residents=maximum_occupancy
    )

    try:
        db.session.add(new_room)
        db.session.commit()
        flash('Room added successfully!', category='success')
    except Exception as e:
        db.session.rollback()
        flash(f'Error adding room: {e}', category='error')

    return redirect(url_for('owner.manage_rooms'))


#DELETE ROOM
@owner.route('delete-room', methods = ['POST'])
def delete_room():
    if current_user.role != 'Owner':
        flash('Access denied. Only owner can delete rooms.', category='error')
        return redirect(url_for('views.home'))
    
    room_id = request.form.get('room_id')

    if not room_id:
        flash('Invalid request: Room ID missing', category='error')
        return redirect(url_for('owner.manage_hostels'))

    try:
        room = db.session.get(Room, int(room_id))
        
        if not room:
            flash(f'Error: Room with ID {room_id} not found.', category='error')
            return redirect(url_for('owner.manage_hostels'))

        room_name = room.room_number
        db.session.delete(room)
        db.session.commit()

        flash(f'Room number"{room_name}" and all associated data successfully deleted.', category='success')
    
    except Exception as e:
        db.session.rollback()
        flash(f'An unexpected error occurred while deleting the room: {e}', category='error')

    return redirect(url_for('owner.manage_rooms'))

#VIEW REPORTS
@owner.route('/viewreports')
def view_reports():
    return render_template('Owner/view_reports.html')

#ADD RESIDENT
@owner.route('/addstudent')
def add_student():
    return render_template('Owner/add_student.html')


@owner.route('/checkin', methods=['POST'])
def check_in_resident():
    if current_user.role != 'Owner':
        flash('Access denied. Access available for owner.', category='error')
        return redirect(url_for('views.home'))
    
    student_reg_no = request.form.get('student_reg_no').upper().strip()
    hostel_id = request.form.get('hostel_id')
    room_number = request.form.get('room_number').upper().strip()

    if not all([student_reg_no, room_number]):
        flash('All fields are required.', category='error')
        return redirect(url_for('owner.manage_residents'))

    room_record = Room.query.filter(
    # Condition 1: Match the user-entered room number (e.g., '101A')
    Room.room_number == room_number,

    # Condition 2: Match the hostel's primary key (Foreign Key check)
    Room.hostel_id == hostel_id 
).first()
    
    room_primary_key_id = None
    if room_record:
        room_primary_key_id = room_record.id
    if not room_record:
        flash('Selected room does not exist in the specified hostel.', category='error')
        return redirect(url_for('owner.manage_residents'))
    if not room_record or not room_record.is_active_for_booking:
        flash('Selected room does not exist or is not available for booking.', category='error')
        return redirect(url_for('owner.manage_residents'))


    student = db.session.get(Student, student_reg_no)
    hostel = db.session.get(Hostel, int(hostel_id))
    if not student:
        flash(f'Student with registration number {student_reg_no} does not exist.', category='error')
        return redirect(url_for('owner.manage_residents'))
    
    if student.gender.lower() == 'male' and hostel.gender_type.lower() == 'female':
        flash("Cannot assign a male student to a female-only hostel.", category='error')
        return redirect(url_for('owner.manage_residents'))

    if student.gender.lower() == 'female' and hostel.gender_type.lower() == 'male':
        flash("Cannot assign a female student to a male-only hostel.", category='error')
        return redirect(url_for('owner.manage_residents'))

    # Check if the student is already a resident
    existing_resident = db.session.query(db.Model.metadata.tables['resident']).filter_by(student_reg_no=student_reg_no).first()
    if existing_resident:
        flash(f'Student {student_reg_no} is already checked in as a resident.', category='error')
        return redirect(url_for('owner.manage_residents'))

    try:
        new_resident = Resident(student_reg_no=student_reg_no, room_id=room_primary_key_id)
        db.session.add(new_resident)
        db.session.commit()
        flash(f'Student {student_reg_no} successfully checked in to room {room_number}.', category='success')
    except Exception as e:
        db.session.rollback()
        flash(f'An unexpected error occurred while checking in the resident: {e}', category='error')

    return redirect(url_for('owner.manage_residents'))
@owner.route('/residents', methods=['GET', 'POST'])
def manage_residents():
    if current_user.role != 'Owner':
        flash('Access denied. Access available for owner.', category='error')
        return redirect(url_for('views.home'))
    

    #NEW CODE BEGIN
    active_residents_count = db.session.query(
        Resident.room_id,
        func.count(Resident.id).label('current_occupancy')
    ).filter(
        Resident.check_out_date == None
    ).group_by(Resident.room_id).subquery()
    
    room_data = db.session.query(
        Room,
        active_residents_count.c.current_occupancy
    ).outerjoin(
        active_residents_count,
        Room.id == active_residents_count.c.room_id
    ).options(
        joinedload(Room.hostel)
    ).all()
    
    hostel_summary = {}

    available_male_rooms = 0
    available_female_rooms = 0
    
    for room, occupancy in room_data:
        current_occupancy = occupancy if occupancy is not None else 0
        
        is_room_available = (
            room.is_active_for_booking and 
            current_occupancy < room.max_residents
        )
        
        hostel_name = room.hostel.name
        hostel_gender = room.hostel.gender_type # Male, Female, or Co-ed
        
        if hostel_name not in hostel_summary:
            hostel_summary[hostel_name] = {
                'total_rooms': 0,
                'available_rooms': 0,
                'total_capacity': 0,
                'total_occupied': 0,
                'gender': hostel_gender
            }
            
        hostel_summary[hostel_name]['total_rooms'] += 1
        hostel_summary[hostel_name]['total_capacity'] += room.max_residents
        hostel_summary[hostel_name]['total_occupied'] += current_occupancy
        
        if is_room_available:
            hostel_summary[hostel_name]['available_rooms'] += 1
            
            # Increment the specific gender counter
            if hostel_gender == 'Male':
                available_male_rooms += 1
            elif hostel_gender == 'Female':
                available_female_rooms += 1
            # Note: Co-ed rooms are counted as available but not added to the specific gender totals.

    # Calculate total available rooms across all hostels (including Co-ed)
    total_available_rooms = sum(h['available_rooms'] for h in hostel_summary.values())
    #NEW CODE END

    #RESIDENTS CURRENTLY CHECKED IN
    current_residents = Resident.query.filter(
        Resident.check_out_date == None
    ).options(
        joinedload(Resident.student),  
        joinedload(Resident.room).joinedload(Room.hostel) 
    ).order_by(Resident.check_in_date.desc()).all()

    total_residents = 0
    for resident in current_residents:
        total_residents += 1
    #HOSTELS BY GENDER
    all_hostels = Hostel.query.filter_by(is_active=True).order_by(Hostel.gender_type, Hostel.name).all()
    hostels_by_gender = {}
    for hostel in all_hostels:
        if hostel.gender_type not in hostels_by_gender:
            hostels_by_gender[hostel.gender_type] = []
        hostels_by_gender[hostel.gender_type].append(hostel)

        
    return render_template(
        'Owner/manage_residents.html',
        hostels_by_gender=hostels_by_gender, residents = current_residents, total_available_rooms=total_available_rooms,hostel_summary=hostel_summary,
        available_male_rooms=available_male_rooms,      
        available_female_rooms=available_female_rooms, total_residents=total_residents,
        user=current_user
    )
